import pandas as pd
import sqlalchemy
import numpy as np
import random


engine = sqlalchemy.create_engine('postgresql://postgres:12345@localhost/northwind')

query = "SELECT * FROM orders"
df_orders = pd.read_sql_query(query, engine)

lista_paises = ['Estados Unidos', 'México', 'Canadá', 'Brasil', 'Argentina', 
                'España', 'Francia', 'Alemania', 'Italia', 'Japón', 'China']

def rellenar_valores_vacios(df):

    df['ship_region'] = df['ship_region'].apply(lambda x: random.choice(lista_paises) if pd.isnull(x) else x)

    assert df['ship_region'].isnull().sum() == 0, "ship_region aún contiene valores nulos."

    df['ship_postal_code'].fillna(np.random.randint(10000, 99999), inplace=True)

    df.to_sql('orders_rellenados', engine, if_exists='replace', index=False)

    return df

df_orders = rellenar_valores_vacios(df_orders)

df_verificacion = pd.read_sql_query("SELECT * FROM orders_rellenados", engine)
print(df_verificacion.tail())
